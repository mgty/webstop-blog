<?php

/*
 * Home short code
 */


class WPBakeryShortCode_virgo_main extends WPBakeryShortCodesContainer
{

}




